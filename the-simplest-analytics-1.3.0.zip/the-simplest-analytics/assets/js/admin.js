/**
 * Simplest Analytics - Admin JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Auto-dismiss notices after 5 seconds
        $('.notice.is-dismissible').delay(5000).fadeOut(400);
    });

})(jQuery);
